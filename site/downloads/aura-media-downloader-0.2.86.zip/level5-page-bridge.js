(() => {
  const REQUEST = "aura-level5-key-request-v1";
  const RESPONSE = "aura-level5-key-response-v1";

  function errorCode(error, fallback) {
    const code = typeof error?.message === "string" ? error.message : "";
    return /^[a-z0-9-]{3,64}$/.test(code) ? code : fallback;
  }

  function bytesFor(value) {
    if (value instanceof ArrayBuffer) return new Uint8Array(value);
    if (ArrayBuffer.isView(value)) return new Uint8Array(value.buffer, value.byteOffset, value.byteLength);
    return null;
  }

  function encode(bytes) {
    let binary = "";
    for (const byte of bytes) binary += String.fromCharCode(byte);
    return btoa(binary);
  }

  function activeHlsSessions() {
    const sessions = [];
    for (const video of document.querySelectorAll("video")) {
      if (video?._l5?.hls?.config?.loader) sessions.push(video._l5.hls);
    }
    return sessions;
  }

  function sameUrl(left, right) {
    try {
      return new URL(left, location.href).href === new URL(right, location.href).href;
    } catch {
      return false;
    }
  }

  function validKeyBytes(value) {
    const bytes = bytesFor(value);
    return bytes && (bytes.byteLength === 16 || bytes.byteLength === 32) ? bytes : null;
  }

  function cachedKey(hls, url) {
    const loaders = new Set();
    if (hls?.streamController?.keyLoader) loaders.add(hls.streamController.keyLoader);
    for (const controller of hls?.networkControllers || []) {
      if (controller?.keyLoader) loaders.add(controller.keyLoader);
      if (controller?.keyUriToKeyInfo) loaders.add(controller);
    }

    for (const loader of loaders) {
      const table = loader?.keyUriToKeyInfo;
      const entries = table instanceof Map ? [...table.values()] : Object.values(table || {});
      for (const info of entries) {
        if (!sameUrl(info?.decryptdata?.uri, url)) continue;
        const bytes = validKeyBytes(info?.decryptdata?.key);
        if (bytes) return bytes;
      }
    }

    const fragments = [
      hls?.streamController?.fragCurrent,
      hls?.streamController?.fragPrevious,
      hls?.streamController?.fragPlaying,
      hls?.audioStreamController?.fragCurrent,
      hls?.audioStreamController?.fragPrevious,
    ];
    for (const level of hls?.levels || []) {
      if (Array.isArray(level?.details?.fragments)) fragments.push(...level.details.fragments);
    }
    if (Array.isArray(hls?.loadLevelObj?.details?.fragments)) {
      fragments.push(...hls.loadLevelObj.details.fragments);
    }
    for (const fragment of fragments) {
      if (!sameUrl(fragment?.decryptdata?.uri, url)) continue;
      const bytes = validKeyBytes(fragment?.decryptdata?.key);
      if (bytes) return bytes;
    }
    return null;
  }

  async function waitForCachedKey(sessions, url, timeoutMs = 1_500) {
    const deadline = Date.now() + timeoutMs;
    while (Date.now() < deadline) {
      for (const hls of sessions) {
        const key = cachedKey(hls, url);
        if (key) return key;
      }
      await new Promise((resolve) => setTimeout(resolve, 100));
    }
    return null;
  }

  function loadKey(hls, url) {
    return new Promise((resolve, reject) => {
      let loader;
      try {
        const Loader = hls.config.loader;
        loader = new Loader(hls.config);
        loader.load({
          url,
          type: "key",
          responseType: "arraybuffer",
          keyInfo: { uri: url, method: "AES-128", keyFormat: "identity" },
        }, {
          timeout: 15_000,
          maxRetry: 1,
          retryDelay: 250,
          maxRetryDelay: 1_000,
        }, {
          onSuccess(response) {
            const bytes = bytesFor(response?.data);
            if (!bytes || (bytes.byteLength !== 16 && bytes.byteLength !== 32)) {
              reject(new Error("invalid-level5-key"));
              return;
            }
            resolve(bytes);
          },
          onError() { reject(new Error("level5-key-load-failed")); },
          onTimeout() { reject(new Error("level5-key-load-timeout")); },
          onProgress() {},
        });
      } catch (error) {
        try { loader?.abort?.(); } catch { /* ignore */ }
        reject(error);
      }
    });
  }

  window.addEventListener("message", async (event) => {
    if (event.source !== window || event.data?.type !== REQUEST) return;
    const requestId = typeof event.data.requestId === "string" ? event.data.requestId : "";
    let url;
    try {
      url = new URL(event.data.url);
      if (!/^https?:$/.test(url.protocol) || !requestId) throw new Error("invalid-request");
    } catch {
      return;
    }

    const sessions = activeHlsSessions();
    for (const hls of sessions) {
      const key = cachedKey(hls, url.href);
      if (!key) continue;
      window.postMessage({ type: RESPONSE, requestId, ok: true, key: encode(key) }, "*");
      return;
    }

    let failure = "level5-key-unavailable";

    const delayedCached = await waitForCachedKey(sessions, url.href);
    if (delayedCached) {
      window.postMessage({ type: RESPONSE, requestId, ok: true, key: encode(delayedCached) }, "*");
      return;
    }

    for (const hls of sessions) {
      try {
        const key = await loadKey(hls, url.href);
        window.postMessage({ type: RESPONSE, requestId, ok: true, key: encode(key) }, "*");
        return;
      } catch (error) {
        const cached = cachedKey(hls, url.href);
        if (cached) {
          window.postMessage({ type: RESPONSE, requestId, ok: true, key: encode(cached) }, "*");
          return;
        }
        if (failure === "not-level5-session-key" || failure === "level5-key-unavailable") {
          failure = errorCode(error, "level5-loader-failed");
        }
        // Try another active Level5 player in this frame.
      }
    }
    window.postMessage({ type: RESPONSE, requestId, ok: false, error: failure }, "*");
  });
})();
